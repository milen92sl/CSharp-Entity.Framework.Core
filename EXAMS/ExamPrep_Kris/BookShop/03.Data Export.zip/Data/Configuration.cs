﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-2LBS7U6\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}