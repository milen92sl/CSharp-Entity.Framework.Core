﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-2LBS7U6\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
